#!/bin/bash
# ============================================================
# AUTO-DEPLOY Rahul Chhallare Portfolio → GitHub Pages
# Run this once on your computer and you're live at:
# https://rahulchhallare.github.io
# ============================================================
# PREREQUISITES: git must be installed (it is on Mac/Linux by default)
# ============================================================

set -e

GITHUB_USERNAME="rahulchhallare"
REPO_NAME="${GITHUB_USERNAME}.github.io"
PORTFOLIO_FILE="rahul-portfolio-final.html"

echo ""
echo "🚀 Deploying your portfolio to GitHub Pages..."
echo "================================================"
echo ""

# Step 1: Check git is installed
if ! command -v git &> /dev/null; then
    echo "❌ git is not installed. Install from https://git-scm.com"
    exit 1
fi

echo "✅ git found"

# Step 2: Ask for GitHub token
echo ""
echo "📋 You need a GitHub Personal Access Token."
echo "   Get one here (takes 30 seconds):"
echo "   https://github.com/settings/tokens/new"
echo "   → Set expiration: No expiration"
echo "   → Check scope: ✅ repo (full control)"
echo "   → Click 'Generate token' → Copy it"
echo ""
read -p "Paste your GitHub token here: " GITHUB_TOKEN
echo ""

if [ -z "$GITHUB_TOKEN" ]; then
    echo "❌ No token provided. Exiting."
    exit 1
fi

# Step 3: Check if repo exists, create if not
echo "📦 Checking if repo ${REPO_NAME} exists..."
REPO_CHECK=$(curl -s -o /dev/null -w "%{http_code}" \
  -H "Authorization: token ${GITHUB_TOKEN}" \
  "https://api.github.com/repos/${GITHUB_USERNAME}/${REPO_NAME}")

if [ "$REPO_CHECK" == "404" ]; then
    echo "   Repo not found — creating it..."
    curl -s -X POST \
      -H "Authorization: token ${GITHUB_TOKEN}" \
      -H "Content-Type: application/json" \
      -d "{\"name\":\"${REPO_NAME}\",\"description\":\"Rahul Chhallare — AI Agent PM Portfolio\",\"public\":true,\"auto_init\":false}" \
      "https://api.github.com/user/repos" > /dev/null
    echo "✅ Repo created: github.com/${GITHUB_USERNAME}/${REPO_NAME}"
    sleep 2
else
    echo "✅ Repo already exists"
fi

# Step 4: Encode portfolio file to base64
echo ""
echo "📄 Encoding portfolio file..."
if [ ! -f "$PORTFOLIO_FILE" ]; then
    echo "❌ File not found: $PORTFOLIO_FILE"
    echo "   Make sure you run this script in the same folder as $PORTFOLIO_FILE"
    exit 1
fi

B64_CONTENT=$(base64 -i "$PORTFOLIO_FILE" | tr -d '\n')
echo "✅ File encoded ($(wc -c < $PORTFOLIO_FILE | tr -d ' ') bytes)"

# Step 5: Check if index.html already exists (need SHA to update)
echo ""
echo "📤 Uploading to GitHub..."
EXISTING=$(curl -s \
  -H "Authorization: token ${GITHUB_TOKEN}" \
  "https://api.github.com/repos/${GITHUB_USERNAME}/${REPO_NAME}/contents/index.html")

SHA=$(echo "$EXISTING" | python3 -c "import sys,json; d=json.load(sys.stdin); print(d.get('sha',''))" 2>/dev/null || echo "")

# Step 6: Upload the file
if [ -n "$SHA" ]; then
    PAYLOAD="{\"message\":\"Update portfolio\",\"content\":\"${B64_CONTENT}\",\"sha\":\"${SHA}\"}"
else
    PAYLOAD="{\"message\":\"Add portfolio site\",\"content\":\"${B64_CONTENT}\"}"
fi

UPLOAD_RESPONSE=$(curl -s -X PUT \
  -H "Authorization: token ${GITHUB_TOKEN}" \
  -H "Content-Type: application/json" \
  -d "$PAYLOAD" \
  "https://api.github.com/repos/${GITHUB_USERNAME}/${REPO_NAME}/contents/index.html")

UPLOAD_STATUS=$(echo "$UPLOAD_RESPONSE" | python3 -c "import sys,json; d=json.load(sys.stdin); print('ok' if 'content' in d else 'error')" 2>/dev/null)

if [ "$UPLOAD_STATUS" != "ok" ]; then
    echo "❌ Upload failed. Response:"
    echo "$UPLOAD_RESPONSE" | python3 -m json.tool 2>/dev/null || echo "$UPLOAD_RESPONSE"
    exit 1
fi

echo "✅ Portfolio uploaded successfully!"

# Step 7: Enable GitHub Pages
echo ""
echo "⚙️  Enabling GitHub Pages..."
PAGES_RESPONSE=$(curl -s -X POST \
  -H "Authorization: token ${GITHUB_TOKEN}" \
  -H "Content-Type: application/json" \
  -d '{"source":{"branch":"main","path":"/"}}' \
  "https://api.github.com/repos/${GITHUB_USERNAME}/${REPO_NAME}/pages" 2>/dev/null)

# Also try PUT in case it already exists
curl -s -X PUT \
  -H "Authorization: token ${GITHUB_TOKEN}" \
  -H "Content-Type: application/json" \
  -d '{"source":{"branch":"main","path":"/"}}' \
  "https://api.github.com/repos/${GITHUB_USERNAME}/${REPO_NAME}/pages" > /dev/null 2>&1

echo ""
echo "================================================"
echo "🎉 DONE! Your portfolio will be live at:"
echo ""
echo "   👉 https://${GITHUB_USERNAME}.github.io"
echo ""
echo "   ⏱️  Usually takes 1–3 minutes to go live."
echo "   🔄 Refresh the URL after 2 minutes."
echo ""
echo "   Share this link on:"
echo "   ✅ LinkedIn profile (Featured section)"
echo "   ✅ Resume / CV"  
echo "   ✅ Email signature"
echo "   ✅ WhatsApp to recruiters"
echo "================================================"
